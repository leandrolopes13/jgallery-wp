jQuery(document).ready(function($) {
    $(".jgallery-item").jgallery();
});